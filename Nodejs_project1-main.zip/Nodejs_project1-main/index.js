var express = require("express");
var mongoose = require("mongoose");
var db = require("./db.js");
db();

const Schema = mongoose.Schema;
const productsschema = new Schema({
  productname: String,
  price: Number,
  discount: Number,
});
const productsModel = mongoose.model("products", productsschema);

// var mysql = require('mysql');

var app = express();
app.use(express.json());

app.get("/products", async function (req, res) {
  try {
    var result = await productsModel.find();
    res.send(result);
  } catch (err) {
    res.send(err.message);
  }
});

app.post("/products", async function (req, res) {
  // res.send("post data from database");
  //console.log(req.body);
  try {
    var record = new productsModel(req.body);
    var ans = await record.save();
    res.send("record inserted successfully");
  } catch (err) {
    res.send(err.message);
  }
});

app.listen(9001);
