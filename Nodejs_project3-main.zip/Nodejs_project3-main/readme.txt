1)npm init -y

2)npm i express mongoose ejs  (ejs its a third party library, it is a part of node.js, it is a viewable part)

  cd C:\Program Files\MongoDB\Server\4.2\bin
3)mongod.exe

4)mongo.exe

5)login mongdb....

6)create views folder
create 3 files--adduser.ejs,showuser.ejs, menu.ejs

7)after app listen(9000) start npm...

8)After menu 

9)then use Schema in index.js

10)in tereminal mongo (db.newusers.insert([{"name":"kajal", "email":"kajalmore356@gmail.com", "mobileNo":7276248312}, {"name":"pankaja", "email":"pankaja@gmail.com", "mobileNo":4556783932}]);

11)await=fetching data from database we use(sending email also)

12)app.use(express.urlencoded()); //for adding data of form we used this command.

zira livm mlul xiei 

13)https://www.nodemailer.com/ Download nodemailer==
const nodemailer = require("nodemailer");

14)port: 587 this port no is fixed for smtp

15)text-u can pass only text
html-u can pass tags also