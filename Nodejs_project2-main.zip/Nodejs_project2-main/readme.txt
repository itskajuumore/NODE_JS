CLI commands
1) npm init -y
2)npm -v[yarn,bower.....]
project2/
npm init -y-->package.jsson
create index.js
run index.js? npm start
npm i express mongoose mysql--node_modules
will be created

2) npm install express (express module its a third party module)
Aftr installing this modulee package-lock .jason file created.

3)KMethod --google -express js

4)default port for mongodb=27017 
fixed port for mongodb=27017 

5)c:\program Files\mongodb\server\4.2\bin(cd )
mongod.exe 
mongo.exe 

use userdetails
show dbs
1)insert()
2)insertOne()
3)insertMany()
4)[]=array is used to store multiple values..

db.users.insert([{"name":"kajal", "age":"20", "place":"Pune"},
{"name":"pankaja", "age":"22", "place":"Nanded"},
{"name":"Sidhu", "age":"22", "place":"nbd"}])

db.users.find()
db.users.find().pretty()...(for formating)
db.users.find({"place":"Pune"})
db.users.remove({"place":"Pune"})

db.users.update({
    "place":"nbd"
},
{
    $set:{
        "place":"Pune",
        "name":"kaju",
        "age":22
    }
})

install mongoose== npm i mongoose
npm mongoose--overview- await(its a anonymous function)

const userModel = mongoose.model('users', usersschema);